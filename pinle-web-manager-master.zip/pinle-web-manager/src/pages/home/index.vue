<template>
    <div>
        <breadcrumb></breadcrumb>
        1111
    </div>
</template>

<script>
import breadcrumb from '../../components/breadcrumb'
export default {
    components:{breadcrumb}
}
</script>

